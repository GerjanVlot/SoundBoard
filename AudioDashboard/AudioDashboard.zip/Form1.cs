﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using NAudio.Wave;
using NAudio.Wave.SampleProviders;
using SharpDX.DirectSound;

namespace AudioDashboard
{
    public partial class Form1 : Form
    {
        private AudioPipeline _audioPipeline;
        private Keyboard _keyBoard;
        private string[] _files;
        private bool[] _isPlaying;
        private AppConfig _config;

        private bool initialized = false;

        public Form1()
        {
            InitializeComponent();

            _config = AppConfig.Load("app.json");
        }

        private void KeyBoard_KeyPress(object sender, KeyEventArgs e)
        {
            var keyMapping = new Dictionary<Keys, string>()
            {
                { Keys.NumPad0, _files[0] },
                { Keys.NumPad1, _files[1] },
                { Keys.NumPad2, _files[2] },
                { Keys.NumPad3, _files[3] },
                { Keys.NumPad4, _files[4] },
                { Keys.NumPad5, _files[5] },
                /*{ Keys.NumPad0, _files[6] },
                { Keys.NumPad0, _files[7] },
                { Keys.NumPad0, _files[8] },
                { Keys.NumPad0, _files[9] },*/
            };

            if (keyMapping.ContainsKey(e.KeyCode))
            {
                Play(keyMapping[e.KeyCode], _config.OutputDevice);

                if (_config.PlayOnSpeaker)
                {
                    Play(keyMapping[e.KeyCode], _config.SpeakerDevice);
                }
            }
        }

        private void Play(string file, int device = 0)
        {
            if (_isPlaying[device]) return;

            _isPlaying[device] = true;
            IWaveProvider waveProvider = new AudioFileReader(file);
            var waveOut = new WaveOut { DeviceNumber = device };
            waveOut.Init(waveProvider);
            waveOut.Play();
            waveOut.PlaybackStopped += (o, args) =>
            {
                _isPlaying[device] = false;
                waveOut.Dispose();
            };
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            for (var i = 0; i < WaveOut.DeviceCount; i++)
            {
                var cap = WaveOut.GetCapabilities(i);
                comboBox1.Items.Add(cap.ProductName);
            }

            for (var i = 0; i < WaveOut.DeviceCount; i++)
            {
                var cap = WaveOut.GetCapabilities(i);
                comboBox3.Items.Add(cap.ProductName);
            }

            for (var i = 0; i < WaveIn.DeviceCount; i++)
            {
                var cap = WaveIn.GetCapabilities(i);
                comboBox2.Items.Add(cap.ProductName);
            }


            comboBox1.SelectedIndex = _config.OutputDevice;
            comboBox3.SelectedIndex = _config.SpeakerDevice;
            comboBox2.SelectedIndex = _config.InputDevice;

            checkBox1.Checked = _config.PlayOnSpeaker;

            Keyboard.Instance.KeyPress += KeyBoard_KeyPress;

            _files = Directory.GetFiles("sounds/");
            _isPlaying = new bool[WaveOut.DeviceCount];

            initialized = true;
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            _config.OutputDevice = comboBox1.SelectedIndex;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            _audioPipeline?.Dispose();

            _audioPipeline = new AudioPipeline()
                .AddInput(new WaveIn() { DeviceNumber = _config.InputDevice })
                .AddProvider(p => new SmbPitchShiftingSampleProvider(p, 1024, 10L, 0.7f))
                .AddProvider(p => new VolumeSampleProvider(p) { Volume = 2f })
                .AddOutput(new WaveOut() { DeviceNumber = _config.OutputDevice });

            _audioPipeline.Start();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            _audioPipeline?.Stop();
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            _config.InputDevice = comboBox1.SelectedIndex;
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            Keyboard.Instance.Dispose();
            _audioPipeline?.Dispose();
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            _config.PlayOnSpeaker = !_config.PlayOnSpeaker;
        }

        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(!initialized) return;
            ;
            _config.SpeakerDevice = comboBox3.SelectedIndex;
        }
    }
}
